import json

def read_json(file_path):
    with open(file_path,'r')as json_file:
      data= json_load(json_file)
    return data