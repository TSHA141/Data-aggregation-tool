import requests
from bs4 import BeautifulSoup

url = 'https://www.scrapethissite.com/'
def scrape_html_data('url'):
    response = requests.get(url)
    soup=BeautifulSoup(response.text,'html.parser')
    data={...}
    return data