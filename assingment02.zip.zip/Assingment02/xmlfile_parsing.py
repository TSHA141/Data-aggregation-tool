import xml.etree.ElementTree as ET

def parse_xml(file_path):
    tree=ET.parse(file_path)
    root=tree.getroot()
    #Extract the data we need
    data={...}
    return data    