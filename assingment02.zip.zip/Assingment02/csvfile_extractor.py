import csv

def extract_csvfile(file_path):
    with open(file_path,'r')as csv_file:
        csv_reader=csv.DictReader(csv_file)
        data = [row for row in csv_reader]
    return data    