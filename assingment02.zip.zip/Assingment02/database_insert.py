#Insert extracted Data into Sqlitedatabase
import sqlite3

def insert_data_into_db(data,table_name):
    connection=sqlite3.connect("your_database.db")
    cursor=connection.cursor()

    for row in data:
        cursor.execute(f"INSERT INTO {table_name} VALUES(?,?,...)",tuple(row.values()))

    connection.commit()
    connection.close()
