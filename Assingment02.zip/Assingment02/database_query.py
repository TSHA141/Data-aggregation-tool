#Data query retrieval
import sqlite3

def search_database(table_name,column_name,search_value):
    connection=sqlite3.connect("data_aggregator.db")
    cursor=connection.cursor()

    query=f"SELECT*FROM {table_name} WHERE{column_name}=?"
    cursor.execute(query,(search_value))
    result=cursor.fetchall()
    connection.close()

    return result