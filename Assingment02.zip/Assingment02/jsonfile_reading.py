import json

def read_json("..\Assingment02\Data\onlinefoods.json"):
    with open("..\Assingment02\Data\onlinefoods.json",'r')as json_file:
      data= json_load(json_file)
    return data