import xml.etree.ElementTree as ET

def parse_xml("..\Assingment02\Data\onlinefoods.xml"):
    tree=ET.parse("..\Assingment02\Data\onlinefoods.csv")
    root=tree.getroot()
    #Extract the data we need
    data={...}
    return data    