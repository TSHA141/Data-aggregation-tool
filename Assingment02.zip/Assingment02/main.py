from database_setup import database_setup
from webscraper import scrape_html_data
from csvfile_extractor import extract_csvfile
from xmlfile_parsing import parse_xml
from jsonfile_reading import read_json
from database_insert import insert_data_into_db
from database_query import search_database

def main():
    database_setup()

    csv_data=extract_csvfile()
    html_data=scrape_html_data()
    xml_data=parse_xml()
    json_data=read_json()

    insert_data_into_db(csv_data,'csv_data')

    result= search_database('csv_data','column1','search_value')
    print(result)

if__name__=='__main__':
    
main()    
