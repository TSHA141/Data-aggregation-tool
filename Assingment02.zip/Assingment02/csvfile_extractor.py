import csv

def extract_csvfile("..\Assingment02\Data\onlinefoods.csv"):
    with open("..\Assingment02\Data\onlinefoods.csv",'r')as csv_file:
        csv_reader=csv.DictReader(csv_file)
        data = [row for row in csv_reader]
    return data    