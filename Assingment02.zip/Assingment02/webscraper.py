import requests
from bs4 import BeautifulSoup

url = 'https://www.kaggle.com/datasets/sudarshan24byte/online-food-dataset'
def scrape_html_data('url'):
    response = requests.get(url)
    soup=BeautifulSoup(response.text,'html.parser')
    data={...}
    return data