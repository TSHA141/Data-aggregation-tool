import sqlite3

#define your database scheme
schema_sql=""""
CREATE TABLE IF NOT EXISTS csv_data(
    id INTEGER PRIMARY KEY,
    column1 text,
    column2 text,
    ...
);

CREATE TABLE IF NOT EXISTS html_data(
    id INTEGER PRIMARY KEY,
    element1 text,
    element2 text,
    ...
);

CREATE TABLEIF NOT EXISTS xml_data(
    id INTEGER PRIMARY KEY,
    element1 text,
    element2 text,
    ...
);

CREATE TABLE IF NOT EXISTS JSON_data(
 id INTEGER PRIMARY KEY,
    element1 text,
    element2 text,
    ...
);
""""

#Now we create the sqlite database
conn = sqlite3.connect("your_database.db")
cursor = conn.cursor()
cursor.executescript(schema_sql)
conn.commit()
conn.close()